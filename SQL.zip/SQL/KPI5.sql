#KPI5 - # of Category Text - As Expected
SELECT
    SUM(CASE WHEN PatientTransfusioncategorytext = 'As Expected' THEN 1 ELSE 0 END) AS TransfusionAsExpected,
    SUM(CASE WHEN Patienthospitalizationcategorytext = 'As Expected' THEN 1 ELSE 0 END) AS HospitalizationAsExpected,
    SUM(CASE WHEN PatientHospitalReadmissionCategory = 'As Expected' THEN 1 ELSE 0 END) AS HospitalReadmissionsAsExpected,
    SUM(CASE WHEN PatientSurvivalCategoryText = 'As Expected' THEN 1 ELSE 0 END) AS SurvivalAsExpected,
    SUM(CASE WHEN PatientInfectioncategorytext = 'As Expected' THEN 1 ELSE 0 END) AS InfectionAsExpected,
    SUM(CASE WHEN FistulaCategoryText = 'As Expected' THEN 1 ELSE 0 END) AS FistulaAsExpected,
    SUM(CASE WHEN SWRcategorytext = 'As Expected' THEN 1 ELSE 0 END) AS SWRAsExpected,
    SUM(CASE WHEN PPPWcategorytext = 'As Expected' THEN 1 ELSE 0 END) AS PPPWAsExpected
FROM
    dialysis1;

