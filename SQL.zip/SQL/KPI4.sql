#KPI4 - Dialysis Stations Stats
SELECT
    State,
    AVG(ExpectedDialysisStations) AS AvgDialysisStations,
    MAX(ExpectedDialysisStations) AS MaxDialysisStations,
    MIN(ExpectedDialysisStations) AS MinDialysisStations,
    COUNT(*) AS TotalFacilities
FROM
    dialysis1
GROUP BY
    State;
 