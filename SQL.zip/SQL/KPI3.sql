#KPI3 - Chain Organizations w.r.t. Total Performance Score as No Score
SELECT 
	d1.ChainOrganization, count(d2.TotalPerformanceScore) as 
    'Total No Score' FROM dialysis1 as d1 JOIN dialysis2 as d2 ON 
    d1.FacilityName = d2.FacilityName WHERE TotalPerformanceScore = 
	'No Score' group by d1.ChainOrganization;

