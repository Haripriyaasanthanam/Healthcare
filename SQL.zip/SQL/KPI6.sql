#KPI6 - AVERAGE PAYMENT REDUCTION RATE.
select concat(round(avg(PY2020PaymentReductionPercentage),2),'%') as 
'AveragePaymentReduction' from dialysis2 where 
PY2020PaymentReductionPercentage <> 'No reduction';