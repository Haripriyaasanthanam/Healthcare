#KPI1 - NUMBER OF PATIENTS ACROSS VARIOUS SUMMARIES.
SELECT
    CONCAT(FORMAT(SUM(IFNULL(transfusionsummary, 0)) / 100000, 2), ' Lakhs') AS TransfusionPatients,
    CONCAT(FORMAT(SUM(IFNULL(hypercalcemiasummary, 0)) / 100000, 2), ' Lakhs') AS HypercalcemiaPatients,
    CONCAT(FORMAT(SUM(IFNULL(Serumphosphorussummary, 0)) / 100000, 2), ' Lakhs') AS SerumPhosphorusPatients,
    CONCAT(FORMAT(SUM(IFNULL(hospitalizationsummary, 0)) / 100000, 2), ' Lakhs') AS HospitalizationPatients,
    CONCAT(FORMAT(SUM(IFNULL(hospitalreadmissionsummary, 0)) / 100000, 2), ' Lakhs') AS HospitalReadmissionPatients,
    CONCAT(FORMAT(SUM(IFNULL(survivalsummary, 0)) / 100000, 2), ' Lakhs') AS SurvivalPatients,
    CONCAT(FORMAT(SUM(IFNULL(Patientsincludedinfistulasummary, 0)) / 100000, 2), ' Lakhs') AS FistulaPatients,
    CONCAT(FORMAT(SUM(IFNULL(longcathetersummary, 0)) / 100000, 2), ' Lakhs') AS LongCatheterPatients,
    SUM(IFNULL(nPCRsummary, 0))  AS nPCRPatients
FROM
    dialysis1;
