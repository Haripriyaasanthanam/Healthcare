#KPI2 - PROFIT VS NON-PROFIT
SELECT
    ProfitorNonProfit,
    COUNT(*) AS TotalCenters,
    AVG(ExpectedDialysisStations) AS AvgDialysisStations,
    AVG(Patientsincludedinfistulasummary) AS AvgFistulaPatients,
    AVG(longcathetersummary) AS AvgLongCatheterPatients
FROM
    dialysis1
GROUP BY
    ProfitorNonProfit;