create database healthcare;
use healthcare;
select * from dialysis1;
select * from dialysis2;
